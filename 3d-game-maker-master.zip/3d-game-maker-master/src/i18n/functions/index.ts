export { default as getLang } from "./getLang";
export { default as translate } from "./translate";
// Alias
export { default as t } from "./translate";