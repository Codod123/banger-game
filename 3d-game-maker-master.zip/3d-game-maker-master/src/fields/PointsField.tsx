function PointsField() {
    return (
        <></>
    );
}

export default PointsField;