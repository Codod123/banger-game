export const collectionName = "gallery";
export { default as add } from "./add";
export { default as byUid } from "./byUid";
export { default as list } from "./list";