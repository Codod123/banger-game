export const collectionName = "games";
export { default as byUid } from "./byUid";
export { default as create } from "./create";
export { default as list } from "./list";
export { default as update } from "./update";