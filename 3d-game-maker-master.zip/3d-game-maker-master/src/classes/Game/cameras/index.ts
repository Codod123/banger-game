export { default as PerspectiveCamera } from "./PerspectiveCamera.class";
export type { PerspectiveCameraOptions } from "./PerspectiveCamera.class";