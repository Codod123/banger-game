export * from "./Light.interface";
export * from "./AmbientLight.interface";
export * from "./DirectionalLight.interface";
export * from "./HemisphereLight.interface";
export * from "./PointLight.interface";
export * from "./SpotLight.interface";