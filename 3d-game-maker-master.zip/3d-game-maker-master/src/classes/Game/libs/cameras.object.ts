const cameras = [
    "PerspectiveCamera",
] as const;

export default cameras;