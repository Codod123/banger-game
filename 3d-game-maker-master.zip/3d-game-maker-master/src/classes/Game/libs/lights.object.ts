const lights = [
    "AmbientLight",
    "DirectionalLight",
    "HemisphereLight",
    "PointLight",
    "SpotLight",
] as const;

export default lights;