export { default as cameras } from "./cameras.object";
export { default as controls } from "./controls.object";
export { default as geometries } from "./geometries.object";
export { default as lights } from "./lights.object";
export { default as materials } from "./materials.object";
export { default as objects3D } from "./objects3D.object";