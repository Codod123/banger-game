const controls = [
    "BaseControls",
    "PointerLockControls",
    "ClassicalControls",
    "RotationControls",
] as const;

export default controls;