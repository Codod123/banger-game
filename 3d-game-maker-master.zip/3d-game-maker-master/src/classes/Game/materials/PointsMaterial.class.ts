import { Game } from "@local/classes";
import { applyBaseMaterialJSON } from "../utils";
import * as THREE from "three";

class PointsMaterial extends THREE.PointsMaterial implements Game.Material {
    public readonly type: "PointsMaterial" = "PointsMaterial";

    public override toJSON(
        meta?: Game.Formats.Meta
    ): Game.Formats.PointsMaterial {
        return super.toJSON(meta);
    }

    public static fromJSON(
        json: Game.Formats.PointsMaterial,
        meta?: Game.Formats.Meta
    ): PointsMaterial {
        const {
            map, // Map uuid
            alphaMap, // Map uuid

            ...params
        } = json;
        const material = new PointsMaterial(params);

        const maps = Object.entries({ map, alphaMap });
        const textures = meta?.textures || {};

        for (const [mapType, mapUuid] of maps) {
            if (mapUuid === undefined) continue;

            const mapJSON = textures[mapUuid];
            if (!mapJSON) continue;

            Game.Texture.fromJSON(mapJSON, meta).then((texture) => {
                // @ts-ignore
                material[mapType] = texture;
                material.needsUpdate = true;
            }).catch(err => {
                console.error(`Error parsing ${mapType} texture:`, err);
            });
        }

        applyBaseMaterialJSON(material, json);

        return material;
    }
}

export default PointsMaterial;