import geometries from "../../geometries/list";
export default geometries;