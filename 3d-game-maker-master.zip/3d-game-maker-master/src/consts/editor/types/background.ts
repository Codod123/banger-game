export default [
    "default",
    "color",
    "uvTexture",
    "equirectTexture"
];