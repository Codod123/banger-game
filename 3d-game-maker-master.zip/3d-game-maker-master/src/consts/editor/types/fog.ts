export default [
    "none",
    "default",
    "exponential",
    "linear"
];