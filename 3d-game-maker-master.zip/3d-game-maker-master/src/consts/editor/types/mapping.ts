export default [
    "none",
    "uvMapping",
    "equirectMapping"
];