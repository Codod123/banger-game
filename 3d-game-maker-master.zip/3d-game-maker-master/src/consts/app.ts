export default {
    name: "3D Game Maker"
};