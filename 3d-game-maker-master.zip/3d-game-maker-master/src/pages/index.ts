export { default as AuthPage } from "./Auth";
export { default as EditorPage } from "./Editor";
export { default as HomePage } from "./Home";
export { default as TestPage } from "./Test";